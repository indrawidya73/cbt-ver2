# Panduan Migrasi CBT Sekolah Sukma ke Supabase

**Untuk:** admin sekolah / operator IT
**Sifat:** sekali jalan (± 20–30 menit), boleh dicicil, **data di perangkat tidak dihapus**
**Hasil akhir:** database sekolah pindah dari Google Sheets (Apps Script) ke **Supabase (PostgreSQL)**.
Tampilan, menu, dan seluruh cara kerja aplikasi **tidak berubah** — siswa, guru, dan pengawas
tetap memakai aplikasi yang sama.

---

## 0. Ringkasan: apa yang berubah, apa yang tidak

| Hal | Sebelum (Apps Script) | Sesudah (Supabase) |
| --- | --- | --- |
| Tempat data | Google Sheets 1 spreadsheet | Tabel PostgreSQL (`students`, `packets`, `questions`, `exams`, `results`, `sessions`, `staff`, `settings`, `logs`) |
| Alamat yang dipakai aplikasi | `https://script.google.com/…/exec` | `https://<project-ref>.supabase.co/functions/v1/sukma-api` |
| Protokol | `?action=…&key=…` (GET) & JSON (POST) | **sama persis** |
| Kunci akses | kunci API sekolah | **kunci API sekolah yang sama** (disimpan sebagai rahasia `SUKMA_API_KEY`) |
| Login siswa/guru | akun di aplikasi | **sama**, tidak memakai Supabase Auth |
| Data di perangkat (localStorage) | ada | **tetap ada** (aplikasi masih bisa jalan offline) |
| Antrean hasil ujian, sesi 1 perangkat, log aktivitas | ada | **sama** |

**Yang perlu disiapkan:**
1. Akun Supabase (gratis) — <https://supabase.com>.
2. Berkas di folder `supabase/`:
   - `01-skema.sql` — tabel, indeks, aturan keamanan, view laporan
   - `02a-data-siswa.sql` — 285 siswa
   - `02b-data-bank-soal.sql` — 41 paket + 689 soal
   - `02c-data-jadwal-akun-log.sql` — 17 jadwal, 13 hasil ujian, 11 akun, 2 catatan log, pengaturan
   - `functions/sukma-api/` — kode API (pengganti `Code.gs`)
3. Aplikasi CBT versi terbaru (`CBT-Sekolah-Sukma.html` / paket Netlify).

> **Penting:** jangan menghapus Google Sheets/Apps Script dulu. Biarkan hidup (tanpa dipakai)
> sampai aplikasi Supabase terbukti cocok selama beberapa hari. Semuanya bisa dibalik.

---

## 1. Buat project Supabase

1. Masuk ke <https://supabase.com/dashboard> → **New project**.
2. Isi:
   - **Name:** `cbt-sukma`
   - **Database Password:** buat sandi kuat, **catat** (dipakai hanya untuk akses langsung ke database).
   - **Region:** `Southeast Asia (Singapore)` — paling dekat ke Indonesia.
3. Tunggu 1–2 menit sampai project siap.
4. Catat dua nilai dari **Project Settings → API**:
   - **Project URL** → bentuknya `https://abcdefghijklm.supabase.co`
   - **anon public key** → hanya sebagai catatan; aplikasi **tidak** memakainya (lihat bagian 8).
5. Alamat API aplikasi nanti adalah: **`<Project URL>/functions/v1/sukma-api`**

---

## 2. Buat tabel (jalankan `01-skema.sql`)

1. Buka **SQL Editor** → **New query**.
2. Tempel seluruh isi `supabase/01-skema.sql` → **Run** (Ctrl/Cmd + Enter).
3. Harus muncul `Success. No rows returned`.

Apa yang dibuat berkas ini:
- 9 tabel + indeks untuk pencarian cepat.
- `updated_at` otomatis.
- **Keamanan:** RLS aktif **tanpa policy** dan hak akses `anon`/`authenticated` dicabut.
  Artinya: alamat database hanya bisa diakses oleh fungsi server (`service_role`),
  **tidak bisa** dibuka dari browser walaupun orang tahu alamat project-nya.
- 2 view laporan: `v_ringkasan_nilai` (rekap nilai per siswa) dan `v_kehadiran_login`
  (rekap login/keluar per pengguna).

### Bentuk tabel (ringkas)

| Tabel | Kunci | Kolom kunci | Isi lain |
| --- | --- | --- | --- |
| `students` | `nis` | `id`, `school`, `class_name` | `data` (objek siswa apa adanya) |
| `packets` | `id` | `school` | `data` |
| `questions` | `id` | `packet_id` | `data` |
| `exams` | `id` | `school`, `packet_id`, `token` | `data` |
| `results` | `result_id` | `exam_id`, `student_nis`, `status` | `data` |
| `sessions` | `session_id` | `nis`, `device_id`, `last_seen`, `status` | `data` |
| `staff` | `username` | `id`, `role`, `scope` | `data` |
| `settings` | `key` | — | `value` |
| `logs` | `id` | `at`, `username`, `role`, `school`, `action` | `data` |

Kolom `data` menyimpan objek aplikasi **apa adanya** (camelCase: `studentNis`, `packetId`, …).
Ini disengaja: aplikasi tidak perlu diubah dan tidak ada data yang hilang saat pindah.

---

## 3. Masukkan data lama (jalankan 02a, 02b, 02c)

Urutannya **penting** (paket dulu, soal menyusul; akun & jadwal terakhir).

| Urutan | Berkas | Isi | Perkiraan waktu |
| --- | --- | --- | --- |
| 1 | `02a-data-siswa.sql` | 285 siswa | ± 5 detik |
| 2 | `02b-data-bank-soal.sql` | 41 paket, 689 soal | ± 30–60 detik (berkas besar, ± 770 KB) |
| 3 | `02c-data-jadwal-akun-log.sql` | 17 jadwal, 13 hasil ujian, 11 akun, 2 log, pengaturan | ± 5 detik |

Cara:
1. **SQL Editor → New query**.
2. Buka berkasnya dengan Notepad/TextEdit → **Ctrl+A, Ctrl+C** → tempel → **Run**.
3. Bila SQL Editor mengeluh "request too large" atau waktu habis pada `02b`:
   - buka berkasnya, lalu jalankan **per blok**: setiap baris `insert into public.questions …;`
     boleh dijalankan sendiri. Cukup jalankan 100–150 baris per sekali Run.
   - aman diulang: semua perintah memakai `on conflict … do update`, jadi menempel dua kali
     **tidak** membuat data ganda.

Semua data disimpan dalam satu transaksi per berkas (`begin; … commit;`) sehingga bila gagal
di tengah, tidak ada data setengah jadi.

### Cara B — kirim lewat API (tanpa menempel berkas besar)

Bila SQL Editor menolak berkas 770 KB atau Anda punya cadangan JSON dari aplikasi
(Pengaturan → **Unduh Backup**), data bisa dikirim lewat fungsi `sukma-api`
setelah langkah 4 selesai:

```bash
node tools/push-data-ke-supabase.mjs cadangan.json \
  https://<project-ref>.supabase.co/functions/v1/sukma-api uji-cbt-sukma-1f4b7c
```

Skrip mencetak perbandingan jumlah baris server vs sumber di akhir. Aman diulang
(semua penulisan memakai upsert, data tidak menggandakan). Cara A dan B boleh
dipakai bersamaan.

### Periksa hasilnya

Jalankan di SQL Editor:

```sql
select 'siswa'     as tabel, count(*) from public.students
union all select 'paket',   count(*) from public.packets
union all select 'soal',    count(*) from public.questions
union all select 'jadwal',  count(*) from public.exams
union all select 'hasil',   count(*) from public.results
union all select 'akun',    count(*) from public.staff
union all select 'log',     count(*) from public.logs
union all select 'setting', count(*) from public.settings;
```

Harus muncul:

| tabel | jumlah |
| --- | --- |
| siswa | **285** |
| paket | **41** |
| soal | **689** |
| jadwal | **17** |
| hasil | **13** |
| akun | **11** |
| log | **2** |
| setting | **≥ 1** |

Cek cepat bahwa objek aplikasi utuh:

```sql
select nis, data->>'name' as nama, data->>'school' as sekolah, data->>'className' as kelas
from public.students order by nis limit 5;

select username, role, scope from public.staff order by username;
-- harus ada: admin, adminsekolah, gurumi, gurusmp, laila, lilacantik,
--            nafian, risda, syahru, tria, yunus
```

---

## 4. Pasang API (Edge Function `sukma-api`)

Fungsi inilah pengganti `Code.gs`. Ada dua cara — pilih **salah satu**.

### Cara A — lewat dasbor Supabase (tanpa memasang apa pun)

1. **Edge Functions → Create a new function**.
2. Nama fungsi: **`sukma-api`** (harus persis).
3. Hapus isi berkas contoh, lalu tempel seluruh isi
   **`supabase/functions/sukma-api/sukma-api-satu-berkas.ts`** (berkas gabungan siap tempel).
4. **WAJIB:** matikan **Verify JWT** (toggle "Enforce JWT verification" / "Verify JWT" → **off**).
   Aplikasi memakai kunci API sekolah sendiri, bukan Supabase Auth. Bila lupa dimatikan,
   semua permintaan akan dijawab `401`.
5. **Deploy** → tunggu sampai status **Active**.
6. Catat alamatnya: `https://<project-ref>.supabase.co/functions/v1/sukma-api`.

### Cara B — lewat Supabase CLI (dianjurkan bila tersedia)

Di komputer yang ada Node.js:

```bash
npm install -g supabase
supabase login
cd <folder-yang-berisi-folder-supabase>
supabase functions deploy sukma-api --project-ref <project-ref> --no-verify-jwt
```

Folder yang dipakai: `supabase/functions/sukma-api/` (`index.ts` + `handler.ts`).
Bendera `--no-verify-jwt` sama gunanya dengan mematikan Verify JWT pada cara A.

### Pasang kunci API sekolah (rahasia)

1. **Edge Functions → Secrets** (atau **Project Settings → Edge Functions → Secrets**).
2. Tambahkan:
   - Name: **`SUKMA_API_KEY`**
   - Value: **`uji-cbt-sukma-1f4b7c`** ← pakai kunci yang **sama** dengan sebelumnya, supaya
     aplikasi & siswa tidak perlu mengubah apa pun. (Boleh diganti kunci baru, tetapi URL/kunci
     di aplikasi juga harus diperbarui.)
3. **`SUPABASE_URL`** dan **`SUPABASE_SERVICE_ROLE_KEY`** sudah tersedia otomatis — **jangan**
   dibuat manual dan **jangan** disebarkan.

> `service_role` key hanya hidup di dalam fungsi server. Aplikasi HTML tidak pernah memegangnya.

### Uji dari terminal

```bash
# 1) tanpa kunci → harus ditolak
curl "https://<project-ref>.supabase.co/functions/v1/sukma-api?action=ping"

# 2) dengan kunci → harus {"ok":true,...}
curl "https://<project-ref>.supabase.co/functions/v1/sukma-api?action=ping&key=uji-cbt-sukma-1f4b7c"
```

Jawaban yang benar:

```json
{"ok":true,"time":"2026-11-01T…","tz":"Asia/Jakarta","version":"supabase-1.0","tag":"SUKMA-SUPABASE-1.0","sheets":["students",…]}
```

Cek isi data lewat API (harus 285 siswa):

```bash
curl "https://<project-ref>.supabase.co/functions/v1/sukma-api?action=getAll&key=uji-cbt-sukma-1f4b7c" \
  | node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{const d=JSON.parse(s).data;console.log('siswa',d.students.length,'paket',d.packets.length,'soal',d.questions.length,'jadwal',d.exams.length,'hasil',d.results.length,'akun',d.staff.length)})"
```

---

## 5. Arahkan aplikasi ke Supabase

Pilih salah satu (boleh keduanya).

### 5.1 Isi sekali dari menu Pengaturan (paling cepat)

1. Buka aplikasi → masuk sebagai **admin**.
2. **Pengaturan → Koneksi Database**.
3. Isi:
   - **Alamat Fungsi Database Supabase:** `https://<project-ref>.supabase.co/functions/v1/sukma-api`
     (boleh hanya alamat project; akhiran `/functions/v1/sukma-api` ditambahkan otomatis)
   - **Kunci API Sekolah:** `uji-cbt-sukma-1f4b7c`
4. Klik **💾 Simpan & Tes Sambungan** → harus muncul "Tersambung ke database sekolah".

Lakukan ini **sekali di setiap perangkat/browser** yang memakai aplikasi versi tanpa URL tertanam
(atau lanjut ke 5.2 supaya tidak perlu diulang).

### 5.2 Tanamkan URL saat build (dianjurkan untuk lab sekolah)

Tujuannya: semua perangkat langsung terhubung tanpa mengisi apa pun.

**Netlify** — Site configuration → Environment variables:

| Name | Value |
| --- | --- |
| `VITE_API_URL` | `https://<project-ref>.supabase.co/functions/v1/sukma-api` |
| `VITE_API_KEY` | `uji-cbt-sukma-1f4b7c` |

Lalu **Deploys → Trigger deploy → Clear cache and deploy site**.

**Build lokal (satu berkas HTML untuk lab):**

```bash
cd cbt-sukma
VITE_API_URL="https://<project-ref>.supabase.co/functions/v1/sukma-api" \
VITE_API_KEY="uji-cbt-sukma-1f4b7c" \
npm run build && npm run standalone
# hasil: dist/cbt-sukma-standalone.html  →  salin ke flashdisk untuk lab
```

Bila URL ditanam, menu Pengaturan menampilkan kotak hijau **"Terhubung otomatis
(tersimpan di aplikasi)"** dan kolom isian disembunyikan.

### 5.3 Perangkat yang dulu memakai Google

Perangkat yang masih menyimpan alamat `script.google.com` **otomatis** dibersihkan setelan lamanya,
supaya aplikasi tidak diam-diam mengirim data ke Google. Setelah itu isi alamat Supabase
(5.1) atau pakai build tertanam (5.2).

**Catatan hasil simulasi.** Pada perangkat yang benar-benar baru (belum pernah membuka
aplikasi), aplikasi membuat data contoh termasuk 12 hasil ujian simulasi agar menu
Analisis bisa dicoba. Begitu data sekolah ditarik dari server, hasil simulasi itu
**otomatis dibuang** (ditandai `demo`) sehingga angka hasil ujian sama dengan isi database
(mis. 13 hasil). Bila perangkat masih menampilkan hasil contoh, klik **Tarik Data** sekali lagi.

---

## 6. Uji cepat setelah terhubung (checklist 10 menit)

Lakukan berurutan di aplikasi, sambil sesekali melihat **Supabase → Table Editor**:

- [ ] **Pengaturan → Tes Koneksi** → "Terhubung · server …"
- [ ] **Pengaturan → Tarik Data** → jumlah diterima: **285 siswa, 41 paket, 689 soal, 17 jadwal**
- [ ] **Data Siswa** menampilkan siswa MI & SMP seperti biasa (filter sekolah tetap jalan untuk admin)
- [ ] **Bank Soal** → buka satu paket, soal & gambar tampil
- [ ] **Jadwal Ujian** → 17 jadwal ada, token terisi
- [ ] **Login siswa** (mis. NIS `240065`, sandi `12345`) → masuk dashboard
- [ ] **Mulai ujian** → **Monitoring** di laptop lain menampilkan siswa itu "MENGERJAKAN"
- [ ] Login siswa yang sama dari **perangkat kedua** → ditolak ("dipakai perangkat lain")
- [ ] Di **Monitoring**, klik **Akhiri Sesi** → perangkat siswa kembali ke halaman login
- [ ] Kumpulkan ujian → nilai masuk; cek `results` di Table Editor
- [ ] **Log Aktivitas** (admin) mencatat login/keluar guru & siswa, termasuk dari perangkat lain
- [ ] **Pengguna** → ubah satu akun guru → simpan → cek tabel `staff` berubah, akun lain utuh
- [ ] Hapus **satu siswa uji** → baris di `students` ikut hilang, siswa lain aman
- [ ] Cetak **Kartu Ujian** & unduh nilai (Excel) tetap berfungsi

Bila semua lolos, migrasi selesai.

---

## 7. Setelah terbukti cocok (1–2 minggu): matikan yang lama

1. **Jangan hapus** Google Sheets/Apps Script — cukup **berhenti memakainya**.
   Bila `Code.gs` masih ter-deploy, matikan lewat Apps Script → **Deploy → Manage deployments →
   Archive**. (Spreadsheet tetap sebagai arsip.)
2. Simpan salinan spreadsheet sebagai arsip (`File → Download → Microsoft Excel`).
3. Bila ada perangkat yang masih memakai aplikasi versi lama (Apps Script), perbarui dengan
   `CBT-Sekolah-Sukma.html` terbaru — jangan biarkan dua versi menulis ke dua database berbeda.

---

## 8. Keamanan (mengapa rancangan ini aman)

| Pertanyaan | Jawaban |
| --- | --- |
| Apakah anon key dipakai? | **Tidak.** anon key hanya dicatat; aplikasi memakai kunci API sekolah. |
| Bisa tidak orang membuka database langsung dari browser? | **Tidak.** RLS aktif tanpa policy + hak `anon`/`authenticated` dicabut. Hanya `service_role` (di dalam fungsi) yang bisa membaca. |
| Di mana `service_role` key disimpan? | Hanya sebagai rahasia Edge Function di server Supabase, tidak pernah dikirim ke perangkat. |
| Bagaimana kalau kunci API sekolah bocor? | Ganti `SUKMA_API_KEY` di Secrets **dan** kunci di aplikasi (Pengaturan / env build). Kunci lama langsung tidak berlaku. |
| Apakah kata sandi siswa/guru bisa dibaca publik? | Tidak lewat API tanpa kunci. Data `password` memang tersimpan apa adanya (seperti di Sheets dulu); jangan bagikan `service_role` key ke siapa pun. |
| Apakah log aktivitas bisa dihapus siswa? | Tidak. API hanya **menambah** log, tidak pernah menghapus. |

**Jangan pernah** menempelkan `service_role` key ke chat, dokumen, atau grup WhatsApp.
Bila sudah terlanjur, segera **Project Settings → API → Reset** lalu perbarui rahasia fungsi.

---

## 9. Bila ada masalah

| Gejala | Penyebab & solusi |
| --- | --- |
| `401 Unauthorized` / `{"code":401}` | **Verify JWT** masih menyala. Matikan (bagian 4) atau deploy ulang dengan `--no-verify-jwt`. |
| `{"ok":false,"error":"Kunci API (key) tidak valid."}` | Kunci di aplikasi ≠ rahasia `SUKMA_API_KEY`. Samakan keduanya. |
| `Gagal terhubung: HTTP 404` | Alamat salah. Harus `https://<project-ref>.supabase.co/functions/v1/sukma-api` (bukan `/rest/v1/`). |
| `relation "public.students" does not exist` | `01-skema.sql` belum dijalankan, atau dijalankan di project lain. |
| `permission denied for table students` | Fungsi memakai kunci yang salah — pastikan `SUPABASE_SERVICE_ROLE_KEY` tidak ditimpa manual. |
| Data kosong padahal SQL sukses | Aplikasi belum **Tarik Data**; atau kunci API beda sehingga jawaban ditolak (cek `Tes Koneksi`). |
| `FuncError: CPU time` / waktu habis saat uji | Berkas `02b` terlalu besar untuk satu Run → jalankan per blok (bagian 3). |
| Aplikasi masih menampilkan data lama setelah deploy | Cache service worker. Muat ulang 2×, atau buka versi build terbaru (nama cache berubah tiap build). |
| Hasil ujian tidak muncul | Hasil diantrekan di perangkat saat internet putus: **Pengaturan → Kirim Hasil Tertunda**. |
| Monitoring kosong padahal siswa mengerjakan | Cek `sessions` di Table Editor; pastikan jam perangkat benar (sesi kedaluwarsa 5 menit tanpa denyut). |

Butuh diagnosa lebih dalam? Menu **Pengaturan → Periksa Kelengkapan Data** membandingkan isi
perangkat dengan server (siswa, paket, soal, jadwal, hasil) dan menampilkan selisihnya.

---

## 10. Perawatan rutin

| Kegiatan | Cara |
| --- | --- |
| Backup database | **Database → Backups** (otomatis harian pada paket berbayar) atau `pg_dump` dengan connection string dari *Project Settings → Database*. Untuk arsip ringan: Table Editor → pilih tabel → **Export CSV**. |
| Melihat rekap nilai | SQL Editor: `select * from public.v_ringkasan_nilai order by sekolah, kelas, nama;` |
| Melihat kehadiran login | SQL Editor: `select * from public.v_kehadiran_login order by terakhir desc limit 50;` |
| Membersihkan sesi mati | `delete from public.sessions where status <> 'active' or last_seen < (extract(epoch from now())*1000 - 86400000);` |
| Menghapus log > 1 tahun | `delete from public.logs where at < now() - interval '1 year';` (opsional) |
| Melihat pemakaian | **Reports / Usage** di dasbor Supabase |

Kuota gratis Supabase (2026): database 500 MB — data sekolah ini (285 siswa, 689 soal)
memakai **< 5 MB**, jadi sangat lega. Batas gratis juga memuat 500.000 pemanggilan fungsi/bulan;
pemakaian normal ujian 300 siswa ≈ 60.000 pemanggilan per hari ujian.

---

## 11. Cara mengembalikan ke Google (rollback)

Sampai Google Sheets masih ada, rollback hanya soal mengarahkan aplikasi kembali:

1. Buka `cbt-sukma/src/config.ts`, isi `DEFAULT_URL` dengan alamat `/exec` lama, build ulang; **atau**
2. Di **Pengaturan → Koneksi Database**, ganti alamat dengan `https://script.google.com/macros/s/…/exec`
   dan kunci API lama, lalu **Simpan & Tes Sambungan**.

Data yang masuk ke Supabase selama masa uji **tidak otomatis** kembali ke Sheets; sebelum
rollback, kirim dulu semua data dari perangkat: **Pengaturan → Tarik Data → Kirim Semua Data**.

---

## 12. Berkas teknis (untuk pengembang)

| Berkas | Isi |
| --- | --- |
| `supabase/01-skema.sql` | tabel, indeks, RLS, view laporan |
| `supabase/02a…02c-*.sql` | data produksi siap tempel |
| `supabase/functions/sukma-api/index.ts` | pembungkus HTTP (CORS, baca rahasia, PostgREST) |
| `supabase/functions/sukma-api/handler.ts` | seluruh logika API (tanpa dependensi), pengganti `Code.gs` |
| `supabase/functions/sukma-api/sukma-api-satu-berkas.ts` | gabungan keduanya, untuk tempel di dasbor |
| `tools/push-data-ke-supabase.mjs` | kirim data lama (JSON) ke Supabase lewat API |
| `qa/test-supabase-api.mjs` | 55 uji protokol API memakai database tiruan |
| `qa/test-postgrest-tiruan.mjs` | 34 uji pembungkus HTTP (halaman >1000 baris, batching, DELETE) |
| `qa/test-setelan-supabase.mjs` | 15 uji halaman Pengaturan → Koneksi Database |
| `qa/test-supabase-asli.mjs` | 16 uji sambungan SUNGGUHAN ke project sekolah (hanya membaca) |
| `qa/mock-supabase-server.mjs` | server tiruan yang menjalankan `handler.ts` asli untuk uji aplikasi |

Protokol yang didukung (sama dengan `Code.gs` 2.13):

```
GET  ?action=ping|getAll|getAllSessions|session|deleteResult&key=…
POST {action:'pushAll'|'submitResult'|'submitResults'|'session'|
              'releaseSession'|'releaseSessions'|'deleteStudents', key:'…'}
```

Aturan yang dipertahankan: sandi siswa kosong tidak menimpa sandi lama (bawaan `12345`);
kiriman akun tanpa satu pun ADMIN ditolak; akun contoh (`guru`, `guru.mi`, …) dibuang;
log hanya ditambah; satu akun siswa hanya boleh aktif di satu perangkat
(TTL sesi 5 menit, "menahan" 2,5 menit, sesi perangkat sama ditandai `replaced`).

---

*Panduan ini dibuat untuk rilis CBT Sekolah Sukma dengan database Supabase. Bila ada langkah yang
tidak cocok dengan tampilan Supabase terbaru, prinsipnya tetap: **buat project → jalankan SQL →
deploy fungsi tanpa Verify JWT → pasang rahasia `SUKMA_API_KEY` → arahkan aplikasi**.*

---

## 8. Buka Blokir Siswa (guru/proktor) — WAJIB fungsi versi 1.2

Sejak 14 November 2026, tombol **Blokir / Buka Blokir** di menu Monitoring
berlaku **lintas perangkat**: keputusan guru dikirim ke server, lalu perangkat
siswa membacanya (tiap ±12 detik) sehingga layar "Ujian Diblokir" hilang sendiri
tanpa login ulang, **jawaban siswa tetap utuh**.

### Perbedaan mode Google Sheets vs Supabase

| Hal | Google Sheets (Apps Script) | Supabase (Edge Function) |
|-----|-----------------------------|--------------------------|
| Tempat data | Spreadsheet (sheet `Results`) | Tabel PostgreSQL `results` |
| Status blokir disimpan di | kolom `blockJson` (baru di 2.14) | kolom JSON `data` (otomatis) |
| Aksi untuk siswa | `?action=getResult&resultId=…` | sama |
| Kecepatan | 0,5–2 detik per penyimpanan, ada kuota harian | milidetik, tanpa kuota harian |
| Syarat agar buka blokir jalan | `Kode-2.14-Apps-Script.gs` + `setupSheets` | `sukma-api-satu-berkas.ts` v1.2 |
| Bila server belum diperbarui | aplikasi memakai jalur cadangan `getAll` (lebih lambat; buka blokir tetap berfungsi) | sama |

### Cara memasang ulang (5 menit)

1. **Supabase** → Edge Functions → `sukma-api` → Edit → hapus semua isi →
   tempel seluruh isi `supabase/functions/sukma-api/sukma-api-satu-berkas.ts`
   → pastikan **Verify JWT mati** → **Deploy**.
2. Uji versi: buka
   `…/functions/v1/sukma-api?action=ping&key=<kunci>` → harus ada
   `"version":"supabase-1.2"` dan `"tag":"SUKMA-SUPABASE-1.2"`.
3. Uji aksi baru: `…?action=getResult&resultId=<id>&key=<kunci>` →
   `{"ok":true,"result":{…}}`. Bila muncul "Aksi tidak dikenal", fungsi belum
   diperbarui (aplikasi masih jalan lewat jalur cadangan).
4. **Google Sheets** (bila masih dipakai): tempel `Kode-2.14-Apps-Script.gs`,
   jalankan `setupSheets`, lalu Deploy versi baru (URL `/exec` tidak berubah).

### Cara memakai di ruang ujian

- Monitoring → pilih **jadwal ujian** (satu jadwal per tampilan) → panel
  **"Perlu Perhatian"** → tombol 🔓 **Buka Blokir**, atau
- tabel peserta → tombol 🚫 **Blokir** / 🔓 **Buka** pada siswa yang mengerjakan.
- Bila ada siswa diblokir di jadwal lain, muncul banner merah
  "N siswa diblokir pada ujian lain" → klik untuk pindah jadwal.
- Perangkat siswa otomatis pulih dalam ±12–15 detik; siswa juga bisa menekan
  "🔄 Saya sudah lapor pengawas — cek lagi".

### Lencana jenis database

Bilah atas semua peran menampilkan lencana: 🗄️ **Supabase**, 📊 **Google
Sheets** (database lama), 💾 **Server sendiri**, atau **Lokal**. Menu
Pengaturan → Koneksi Database menampilkan uraian yang sama.
