/**
 * ============================================================================
 *  CBT SEKOLAH SUKMA — FUNGSI "sukma-api" (SATU BERKAS, SIAP TEMPEL)
 * ----------------------------------------------------------------------------
 *  Gabungan index.ts + handler.ts untuk dipasang lewat editor dasbor Supabase:
 *
 *    1. Edge Functions → Create a new function → nama: sukma-api
 *    2. Hapus isi berkas contoh, tempel SELURUH isi berkas ini
 *    3. Matikan "Verify JWT" (WAJIB) → Deploy
 *    4. Edge Functions → Secrets → SUKMA_API_KEY = kunci API sekolah
 *
 *  Versi: 1.3 (2026-11-01) — tag SUKMA-SUPABASE-1.3
 *    • BARU: aksi `hapusbank` — menghapus paket soal dan/atau soal secara
 *      PERMANEN di database. Sebelumnya server hanya bisa menimpa (upsert),
 *      sehingga paket yang dihapus di perangkat HIDUP LAGI saat Tarik Data.
 *      Payload: { action: "hapusbank", packetIds: [], questionIds: [] }
 *      Soal milik paket yang dihapus ikut terhapus. Data siswa & hasil ujian
 *      tidak disentuh.
 *    • `pushAll` kini menjalankan penghapusan (data.hapus) SESUDAH upsert,
 *      supaya paket yang dihapus klien tidak dihidupkan lagi oleh kiriman
 *      data lama dari perangkat lain.
 *    • Sejak 1.2: aksi `getResult` (GET ?action=getResult&resultId=… atau &nis=…)
 *      supaya perangkat siswa bisa memantau keputusan "Blokir / Buka Blokir".
 *    • Sejak 1.1: pembacaan tabel memakai halaman limit/offset (aman untuk
 *      bank soal > 1000 baris).
 *
 *  Jangan disunting tangan — dihasilkan dari index.ts + handler.ts di folder
 *  ini (esbuild --bundle).
 * ============================================================================
 */

// supabase/functions/sukma-api/handler.ts
var DEMO_STAF_USERNAMES = [
  "guru",
  "guru.mi",
  "guru.mi2",
  "guru.mi3",
  "guru.mi4",
  "guru.mi5",
  "guru.smp",
  "guru.smp2",
  "guru.smp3",
  "guru.smp4",
  "guru.smp5"
];
var TTL = 5 * 60 * 1e3;
var BLOCK = 150 * 1e3;
var nowIso = () => (/* @__PURE__ */ new Date()).toISOString();
var userKey = (v) => String(v ?? "").trim().toLowerCase();
var nisKey = (v) => {
  const s = String(v ?? "").trim().replace(/\s+/g, "");
  const t = s.replace(/^0+/, "");
  return t || s;
};
var ok = (body) => ({ status: 200, body: { ok: true, ...body } });
var gagal = (error) => ({ status: 200, body: { ok: false, error } });
var sesiDari = (row) => ({
  nis: String(row.nis ?? ""),
  sessionId: String(row.session_id ?? ""),
  deviceId: String(row.device_id ?? ""),
  deviceLabel: String(row.data?.deviceLabel ?? ""),
  startedAt: String(row.data?.startedAt ?? ""),
  lastSeen: Number(row.last_seen ?? 0),
  examId: row.data?.examId ? String(row.data.examId) : "",
  status: String(row.status ?? "active")
});
var sesiRow = (s, status = "active") => ({
  session_id: String(s.sessionId),
  nis: String(s.nis ?? ""),
  device_id: String(s.deviceId ?? ""),
  last_seen: Number(s.lastSeen ?? 0),
  status,
  data: { ...s, status }
});
async function handleRequest(req, db, cfg) {
  const params = req.params || {};
  const body = req.body || {};
  const key = String(body.key ?? params.key ?? "");
  if (key !== cfg.apiKey) return gagal("Kunci API (key) tidak valid.");
  const action = String(body.action ?? params.action ?? "ping").toLowerCase();
  const sekarang = () => cfg.now ? cfg.now() : Date.now();
  const ttl = cfg.sessionTtlMs ?? TTL;
  const block = cfg.sessionBlockMs ?? BLOCK;
  try {
    if (action === "ping") {
      return ok({
        time: nowIso(),
        tz: "Asia/Jakarta",
        version: "supabase-1.3",
        tag: "SUKMA-SUPABASE-1.3",
        sheets: ["students", "packets", "questions", "exams", "results", "sessions", "staff", "settings", "logs"]
      });
    }
    if (action === "getall" || action === "getAll".toLowerCase()) {
      const [students, packets, questions, exams, results, staff, settings, logs] = await Promise.all([
        db.select("students"),
        db.select("packets"),
        db.select("questions"),
        db.select("exams"),
        db.select("results"),
        db.select("staff"),
        db.select("settings"),
        db.select("logs")
      ]);
      const pengaturan = {};
      settings.forEach((s) => {
        pengaturan[String(s.key)] = String(s.value ?? "");
      });
      const urutLog = [...logs].sort((a, b) => String(a.at ?? "").localeCompare(String(b.at ?? "")));
      return ok({
        data: {
          pengaturan,
          staff: staff.map((r) => r.data),
          logs: urutLog.slice(-500).map((r) => r.data),
          students: students.map((r) => r.data),
          results: results.map((r) => r.data),
          exams: exams.map((r) => r.data),
          questions: questions.map((r) => r.data),
          packets: packets.map((r) => r.data)
        }
      });
    }
    if (action === "getallsessions") {
      const rows = await db.select("sessions");
      const hidup = rows.map(sesiDari).filter((s) => s.status === "active" && sekarang() - s.lastSeen < ttl);
      return ok({ sessions: hidup });
    }
    if (action === "session") {
      const payload = { ...body.session || {}, ...params, ...body };
      return await aksiSesi(payload, db, sekarang(), ttl, block);
    }
    if (action === "getresult") {
      const resultId = String(params.resultId ?? body.resultId ?? "");
      const nis = String(params.nis ?? body.nis ?? "");
      const examId = String(params.examId ?? body.examId ?? "");
      if (!resultId && !nis) return gagal("Isi resultId atau nis yang dicari.");
      const rows = await db.select("results");
      const baris = resultId ? rows.find((r) => String(r.result_id) === resultId) : rows.find(
        (r) => nisKey(r.student_nis) === nisKey(nis) && (!examId || String(r.exam_id) === examId)
      );
      return ok({ result: baris ? baris.data : null });
    }
    if (action === "deleteresult") {
      const resultId = String(params.resultId ?? body.resultId ?? "");
      const nis = String(params.nis ?? body.nis ?? "");
      if (!resultId && !nis) return gagal("Isi resultId atau nis yang akan dihapus.");
      const rows = await db.select("results");
      const buang = rows.filter(
        (r) => resultId ? String(r.result_id) === resultId : nisKey(r.student_nis) === nisKey(nis)
      ).map((r) => String(r.result_id));
      if (buang.length) await db.del("results", "result_id", buang);
      return ok({ deleted: buang.length });
    }
    if (action === "hapusbank") {
      const hasil = await hapusBankSoal(body.packetIds || [], body.questionIds || [], db);
      return ok(hasil);
    }
    if (action === "pushall") {
      return await pushAll(body.data || {}, db);
    }
    if (action === "submitresult") {
      const hasil = body.result || {};
      if (!hasil.id) return gagal("Data hasil tidak valid (id kosong).");
      await db.upsert(
        "results",
        [{
          result_id: String(hasil.id),
          exam_id: String(hasil.examId ?? ""),
          student_nis: String(hasil.studentNis ?? ""),
          status: String(hasil.status ?? "submitted"),
          data: { ...hasil, updatedAt: nowIso() }
        }],
        "result_id"
      );
      return ok({ mode: "saved", resultId: hasil.id, savedAt: nowIso() });
    }
    if (action === "submitresults") {
      const daftar = (body.results || []).filter((r) => r && r.id);
      if (daftar.length) {
        await db.upsert(
          "results",
          daftar.map((r) => ({
            result_id: String(r.id),
            exam_id: String(r.examId ?? ""),
            student_nis: String(r.studentNis ?? ""),
            status: String(r.status ?? "submitted"),
            data: { ...r, updatedAt: nowIso() }
          })),
          "result_id"
        );
      }
      return ok({ saved: daftar.length, errors: [] });
    }
    if (action === "releasesession") {
      const nisLepas = String(body.nis ?? params.nis ?? "");
      const semuaRow = await db.select("sessions");
      const kena = semuaRow.map((r) => ({ ...sesiDari(r), __row: r })).filter((s) => s.status === "active" && userKey(s.nis) === userKey(nisLepas));
      if (kena.length) {
        await db.upsert(
          "sessions",
          kena.map((s) => sesiRow({ ...tanpa__(s), releasedBy: "guru" }, "released")),
          "session_id"
        );
      }
      return ok({ released: kena.length });
    }
    if (action === "releasesessions") {
      const rows = await db.select("sessions");
      const aktif = rows.filter((r) => String(r.status) === "active");
      if (aktif.length) {
        await db.upsert(
          "sessions",
          aktif.map((r) => ({ ...r, status: "released", data: { ...r.data || {}, status: "released" } })),
          "session_id"
        );
      }
      return ok({ released: aktif.length });
    }
    if (action === "deletestudents") {
      const list = (body.nisList || body.nis || []).map(nisKey);
      const prefixes = (body.prefixes || []).map(nisKey);
      const rows = await db.select("students");
      const buang = rows.filter((r) => {
        const nis = nisKey(r.nis);
        if (!nis) return false;
        if (list.includes(nis)) return true;
        return prefixes.some((p) => p && nis.startsWith(p));
      }).map((r) => String(r.nis));
      if (buang.length) await db.del("students", "nis", buang);
      return ok({ deleted: buang.length });
    }
    return gagal("Aksi tidak dikenal: " + action);
  } catch (err) {
    console.error("API error:", err);
    return gagal(String(err?.message || err));
  }
}
async function hapusBankSoal(packetIds, questionIds, db) {
  const paket = (packetIds || []).map((x) => String(x ?? "").trim()).filter(Boolean);
  const soal = new Set((questionIds || []).map((x) => String(x ?? "").trim()).filter(Boolean));
  if (paket.length) {
    const rows = await db.select("questions");
    const setPaket = new Set(paket);
    rows.forEach((r) => {
      if (setPaket.has(String(r.packet_id ?? ""))) soal.add(String(r.id));
    });
    await db.del("packets", "id", paket);
  }
  if (soal.size) await db.del("questions", "id", Array.from(soal));
  return { ok: true, packets: paket.length, questions: soal.size };
}
async function pushAll(data, db) {
  const counts = { students: 0, packets: 0, questions: 0, exams: 0, results: 0, logs: 0 };
  if (Array.isArray(data.students) && data.students.length) {
    const lama = await db.select("students");
    const sandiLama = /* @__PURE__ */ new Map();
    lama.forEach((r) => sandiLama.set(nisKey(r.nis), String(r.data?.password ?? "")));
    const rows = data.students.map((s) => {
      const nis = String(s.nis ?? "").trim();
      if (!nis) return null;
      const sandiBaru = String(s.password ?? "").trim();
      const sandi = sandiBaru || sandiLama.get(nisKey(nis)) || "12345";
      const record = { ...s, nis, password: sandi };
      return {
        nis,
        id: String(s.id ?? ""),
        school: String(s.school ?? ""),
        class_name: String(s.className ?? ""),
        data: record
      };
    }).filter(Boolean);
    if (rows.length) await db.upsert("students", rows, "nis");
    counts.students = rows.length;
  }
  if (Array.isArray(data.packets) && data.packets.length) {
    await db.upsert(
      "packets",
      data.packets.map((p) => ({ id: String(p.id), school: String(p.school ?? ""), data: p })),
      "id"
    );
    counts.packets = data.packets.length;
  }
  if (Array.isArray(data.questions) && data.questions.length) {
    await db.upsert(
      "questions",
      data.questions.map((q) => ({ id: String(q.id), packet_id: String(q.packetId ?? ""), data: q })),
      "id"
    );
    counts.questions = data.questions.length;
  }
  if (Array.isArray(data.exams) && data.exams.length) {
    await db.upsert(
      "exams",
      data.exams.map((e) => ({
        id: String(e.id),
        school: String(e.school ?? ""),
        packet_id: String(e.packetId ?? ""),
        token: String(e.token ?? ""),
        data: e
      })),
      "id"
    );
    counts.exams = data.exams.length;
  }
  if (data.hapus && typeof data.hapus === "object") {
    const h = data.hapus;
    const hasil = await hapusBankSoal(h.packets || [], h.questions || [], db);
    counts.hapusPackets = hasil.packets;
    counts.hapusQuestions = hasil.questions;
  }
  if (Array.isArray(data.results) && data.results.length) {
    await db.upsert(
      "results",
      data.results.filter((r) => r && r.id).map((r) => ({
        result_id: String(r.id),
        exam_id: String(r.examId ?? ""),
        student_nis: String(r.studentNis ?? ""),
        status: String(r.status ?? "submitted"),
        data: r
      })),
      "result_id"
    );
    counts.results = data.results.length;
  }
  if (Array.isArray(data.logs) && data.logs.length) {
    const rows = data.logs.filter((l) => l && l.id).map((l) => ({
      id: String(l.id),
      at: l.at ? String(l.at) : nowIso(),
      username: String(l.username ?? ""),
      name: String(l.name ?? ""),
      role: String(l.role ?? ""),
      school: String(l.school ?? ""),
      action: String(l.action ?? "login"),
      data: { ...l, sent: true }
    }));
    if (rows.length) await db.insertIgnore("logs", rows, "id");
    counts.logs = rows.length;
  }
  if (Array.isArray(data.staff)) {
    const replace = data.staffMode === "replace";
    const bersih = data.staff.filter((acc) => {
      const u = userKey(acc?.username);
      return u && DEMO_STAF_USERNAMES.indexOf(u) === -1;
    });
    if (replace && !bersih.some((a) => String(a.role || "").toUpperCase() === "ADMIN")) {
      return gagal("Kiriman akun ditolak: daftar akun harus berisi minimal satu Administrator.");
    }
    if (replace) await db.delAll("staff");
    if (bersih.length) {
      await db.upsert(
        "staff",
        bersih.map((acc) => {
          const username = userKey(acc.username);
          return {
            username,
            id: String(acc.id ?? `stf-${username}`),
            role: String(acc.role ?? "TEACHER"),
            scope: String(acc.scope ?? "Semua"),
            data: { ...acc, username }
          };
        }),
        "username"
      );
    }
  }
  if (data.pengaturan && typeof data.pengaturan === "object") {
    const rows = Object.entries(data.pengaturan).map(([k, v]) => ({
      key: k,
      value: String(v ?? "")
    }));
    if (rows.length) await db.upsert("settings", rows, "key");
  }
  return ok({ counts });
}
async function aksiSesi(payload, db, now, ttl, block) {
  const type = String(payload.type || "check").toLowerCase();
  const rows = await db.select("sessions");
  const semua = rows.map((r) => ({ ...sesiDari(r), __row: r }));
  const hidup = semua.filter((s) => s.status === "active" && now - s.lastSeen < ttl);
  const menahan = semua.filter((s) => s.status === "active" && now - s.lastSeen < block);
  if (type === "check") {
    const nis = String(payload.nis ?? "");
    const deviceId = String(payload.deviceId ?? "");
    const bentrok = menahan.find(
      (s) => userKey(s.nis) === userKey(nis) && s.deviceId !== deviceId
    );
    return ok({ blocked: !!bentrok, blockedBy: bentrok ? tanpa__(bentrok) : null });
  }
  if (type === "start") {
    const s = payload.session || {};
    const nis = String(s.nis ?? payload.nis ?? "");
    if (!nis) return gagal("NIS wajib diisi.");
    const sessionId = String(s.sessionId ?? payload.sessionId ?? "");
    const deviceId = String(s.deviceId ?? payload.deviceId ?? "");
    if (!sessionId) return gagal("sessionId wajib diisi.");
    const bentrok = menahan.find(
      (x) => userKey(x.nis) === userKey(nis) && x.sessionId !== sessionId && x.deviceId !== deviceId
    );
    if (bentrok) return ok({ blocked: true, blockedBy: tanpa__(bentrok) });
    const ganti = menahan.filter(
      (x) => x.sessionId !== sessionId && userKey(x.nis) === userKey(nis) && x.deviceId === deviceId
    );
    if (ganti.length) {
      await db.upsert(
        "sessions",
        ganti.map((x) => sesiRow(tanpa__(x), "replaced")),
        "session_id"
      );
    }
    await db.upsert(
      "sessions",
      [sesiRow({ ...s, nis, sessionId, deviceId, lastSeen: now, status: "active" })],
      "session_id"
    );
    return ok({ blocked: false, sessionId });
  }
  if (type === "heartbeat") {
    const sessionId = String(payload.sessionId ?? payload.session?.sessionId ?? "");
    const ada = semua.find((s) => s.sessionId === sessionId);
    if (!ada) return ok({ found: false, released: true, code: "notfound" });
    if (ada.status !== "active") {
      const kode = ada.__row?.data?.releasedBy === "guru" ? "kicked" : "ended";
      return ok({ found: true, released: true, code: kode, sessionId });
    }
    await db.upsert(
      "sessions",
      [sesiRow({ ...tanpa__(ada), lastSeen: now, status: "active" })],
      "session_id"
    );
    return ok({ found: true, released: false, sessionId });
  }
  if (type === "end" || type === "release") {
    const sessionId = String(payload.sessionId ?? payload.session?.sessionId ?? "");
    const nis = String(payload.nis ?? "");
    const kena = semua.filter(
      (s) => sessionId ? s.sessionId === sessionId : userKey(s.nis) === userKey(nis)
    );
    if (kena.length) {
      await db.upsert(
        "sessions",
        kena.map((s) => sesiRow({ ...tanpa__(s), status: "released" }, "released")),
        "session_id"
      );
    }
    return ok({ released: kena.length });
  }
  if (type === "list") return ok({ sessions: hidup.map(tanpa__) });
  return gagal("Tipe sesi tidak dikenal: " + type);
}
var tanpa__ = (s) => {
  const salinan = { ...s };
  delete salinan.__row;
  return salinan;
};

// supabase/functions/sukma-api/index.ts
var BATCH = 500;
var PAGE = 1e3;
var KUNCI_BAWAAN = "uji-cbt-sukma-1f4b7c";
var env = (nama) => {
  try {
    const d2 = globalThis.Deno;
    if (d2?.env?.get) return String(d2.env.get(nama) ?? "");
  } catch {
  }
  try {
    return String(globalThis.process?.env?.[nama] ?? "");
  } catch {
    return "";
  }
};
var BASE = env("SUPABASE_URL").replace(/\/+$/, "");
var SERVICE = env("SUPABASE_SERVICE_ROLE_KEY");
var header = () => ({
  apikey: SERVICE,
  Authorization: `Bearer ${SERVICE}`,
  "Content-Type": "application/json",
  Accept: "application/json"
});
var potong = (arr, n) => {
  const hasil = [];
  for (let i = 0; i < arr.length; i += n) hasil.push(arr.slice(i, i + n));
  return hasil;
};
var buatDb = () => {
  const tabel = (nama) => `${BASE}/rest/v1/${encodeURIComponent(nama)}`;
  const kirim = async (url, init) => {
    const res = await fetch(url, init);
    if (!res.ok) {
      const teks = await res.text();
      throw new Error(`Supabase ${res.status}: ${teks.slice(0, 300)}`);
    }
    return res;
  };
  return {
    /**
     * Baca seluruh isi tabel.
     *
     * PostgREST membatasi 1000 baris per permintaan, jadi dibaca per halaman
     * dengan `limit` + `offset`. Tanpa ini bank soal yang melewati 1000 soal
     * (atau log yang menumpuk) akan terpotong tanpa pesan apa pun.
     */
    async select(nama) {
      const semua = [];
      for (let offset = 0; ; offset += PAGE) {
        const res = await kirim(
          `${tabel(nama)}?select=*&limit=${PAGE}&offset=${offset}`,
          { headers: header() }
        );
        const halaman = await res.json();
        if (!Array.isArray(halaman) || halaman.length === 0) break;
        semua.push(...halaman);
        if (halaman.length < PAGE) break;
      }
      return semua;
    },
    /** Tambah/ubah baris; bentrok pada `onConflict` → ditimpa. */
    async upsert(nama, rows, onConflict) {
      for (const bagian of potong(rows, BATCH)) {
        await kirim(`${tabel(nama)}?on_conflict=${encodeURIComponent(onConflict)}`, {
          method: "POST",
          headers: { ...header(), Prefer: "resolution=merge-duplicates,return=minimal" },
          body: JSON.stringify(bagian)
        });
      }
    },
    /** Tambah baris; bentrok pada `onConflict` → dilewati (untuk log). */
    async insertIgnore(nama, rows, onConflict) {
      for (const bagian of potong(rows, BATCH)) {
        await kirim(`${tabel(nama)}?on_conflict=${encodeURIComponent(onConflict)}`, {
          method: "POST",
          headers: { ...header(), Prefer: "resolution=ignore-duplicates,return=minimal" },
          body: JSON.stringify(bagian)
        });
      }
    },
    /** Hapus baris dengan nilai kolom tertentu. */
    async del(nama, column, values) {
      for (const bagian of potong(values, 100)) {
        const daftar = bagian.map((v) => `"${String(v).replace(/"/g, '\\"')}"`).join(",");
        await kirim(`${tabel(nama)}?${encodeURIComponent(column)}=in.(${encodeURIComponent(daftar)})`, {
          method: "DELETE",
          headers: { ...header(), Prefer: "return=minimal" }
        });
      }
    },
    /** Kosongkan tabel. */
    async delAll(nama) {
      await kirim(`${tabel(nama)}?${encodeURIComponent("id")}=not.is.null`, {
        method: "DELETE",
        headers: { ...header(), Prefer: "return=minimal" }
      });
    }
  };
};
var cariKunci = async (db) => {
  const dariEnv = env("SUKMA_API_KEY").trim();
  if (dariEnv) return dariEnv;
  try {
    const rows = await db.select("settings");
    const baris = rows.find((r) => String(r.key) === "apiKey");
    const nilai = String(baris?.value ?? "").trim();
    if (nilai) return nilai;
  } catch {
  }
  return KUNCI_BAWAAN;
};
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, X-Client-Version",
  "Access-Control-Max-Age": "86400"
};
var jawab = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    ...CORS,
    "Content-Type": "application/json; charset=utf-8",
    // Apps Script lama selalu no-store; jangan sampai hasil ujian ter-cache.
    "Cache-Control": "no-store, no-cache, must-revalidate"
  }
});
var suntikVersi = (req) => {
};
var layani = async (req) => {
  suntikVersi(req);
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (!BASE || !SERVICE) {
    return jawab(
      {
        ok: false,
        error: "Fungsi belum lengkap: SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY tidak terbaca. Pastikan fungsi ini dijalankan di Supabase (bukan di komputer lokal)."
      },
      500
    );
  }
  const url = new URL(req.url);
  const params = {};
  url.searchParams.forEach((v, k) => {
    params[k] = v;
  });
  let body = {};
  if (req.method === "POST") {
    const teks = await req.text();
    if (teks.trim()) {
      try {
        body = JSON.parse(teks);
      } catch {
        return jawab({ ok: false, error: "Isi permintaan bukan JSON yang sah." });
      }
    }
  }
  try {
    const db = buatDb();
    const cfg = {
      apiKey: await cariKunci(db),
      now: () => Date.now()
    };
    const hasil = await handleRequest({ method: req.method, params, body }, db, cfg);
    return jawab(hasil.body, hasil.status);
  } catch (err) {
    const pesan = err instanceof Error ? err.message : String(err);
    return jawab({ ok: false, error: `Kesalahan server: ${pesan}` }, 200);
  }
};
var d = globalThis.Deno;
if (d?.serve) {
  d.serve(layani);
}
var sukma_api_default = { fetch: layani };
export {
  sukma_api_default as default,
  layani
};
